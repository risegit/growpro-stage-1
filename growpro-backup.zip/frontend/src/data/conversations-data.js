export const conversationsData = [
  {
    img: "/img/team-1.jpeg",
    name: "Sophie B.",
    message: "Hi! I need more information...",
  },
  {
    img: "/img/team-2.jpeg",
    name: "Alexander",
    message: "Awesome work, can you...",
  },
  {
    img: "/img/team-3.jpeg",
    name: "Ivanna",
    message: "About files I can...",
  },
  {
    img: "/img/team-4.jpeg",
    name: "Peterson",
    message: "Have a great afternoon...",
  },
  {
    img: "/img/bruce-mars.jpeg",
    name: "Bruce Mars",
    message: "Hi! I need more information...",
  },
];

export default conversationsData;
